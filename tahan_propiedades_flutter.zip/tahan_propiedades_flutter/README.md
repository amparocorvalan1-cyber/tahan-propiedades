# Tahan Propiedades (Flutter)

App móvil de Veronica Tahan Negocios Inmobiliarios. DUO Apps Development.
**Sin geolocalización**: no hay GPS, mapas ni permisos de ubicación.

## Cómo correrla
1. Instalá Flutter: https://docs.flutter.dev/get-started/install
2. En esta carpeta, creá las carpetas de Android/iOS (solo la primera vez):
   `flutter create .`
   (no pisa `lib/` ni `pubspec.yaml`; si pregunta por sobrescribir, decí que no)
3. `flutter pub get`
4. `flutter run`  (con el celular conectado o un emulador)

### Para que abran los enlaces en Android
En `android/app/src/main/AndroidManifest.xml`, dentro de `<manifest>` y antes de `<application>`, agregá:

```xml
<queries>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
  <intent><action android:name="android.intent.action.SENDTO"/><data android:scheme="mailto"/></intent>
</queries>
```

## Estructura
- `assets/screens/s-01..s-22.jpg`: las pantallas del diseño (1 Inicio, 2-10 venta, 11-19 alquiler, 20 Contáctanos, 21 Nosotros, 22 logo/bienvenida).
- `lib/main.dart`: pantallas con zonas táctiles invisibles sobre cada botón.
